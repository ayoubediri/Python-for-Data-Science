# ft_package

A sample test package containing a single function: `count_in_list`.

## Installation

To install the package, you can use:

```bash
pip install ./dist/ft_package-0.0.1.tar.gz
```